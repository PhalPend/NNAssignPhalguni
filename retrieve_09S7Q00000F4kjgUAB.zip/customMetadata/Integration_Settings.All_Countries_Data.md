<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>All Countries Data</label>
    <protected>false</protected>
    <values>
        <field>API_Key__c</field>
        <value xsi:type="xsd:string">c23679e737676aba78f4dae3b25d7b0b</value>
    </values>
    <values>
        <field>EndPoint__c</field>
        <value xsi:type="xsd:string">http://api.countrylayer.com/v2/all?access_key=</value>
    </values>
    <values>
        <field>HttpMethod__c</field>
        <value xsi:type="xsd:string">GET</value>
    </values>
    <values>
        <field>URLParameter__c</field>
        <value xsi:type="xsd:string">access_key</value>
    </values>
</CustomMetadata>
